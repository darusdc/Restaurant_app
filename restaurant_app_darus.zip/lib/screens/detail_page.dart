import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:restaurant_app/models/restaurant.dart';

class RestaurantDetailPage extends StatelessWidget {
  static const routeName = '/restaurant_detail';

  final Restaurant restaurant;

  const RestaurantDetailPage({Key? key, required this.restaurant})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    List foods = restaurant.menus['foods'];
    List drinks = restaurant.menus['drinks'];
    ScrollController sc = ScrollController();
    return Scaffold(
      body: NestedScrollView(
        controller: kIsWeb
            ? null
            : Platform.isAndroid || Platform.isIOS
                ? sc
                : null,
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              pinned: true,
              expandedHeight: 200,
              flexibleSpace: FlexibleSpaceBar(
                background: Hero(
                    tag: restaurant.id,
                    child: Image.network(
                      restaurant.pictureId,
                      fit: BoxFit.cover,
                    )),
                title: Text(restaurant.name,
                    style: Theme.of(context).textTheme.titleLarge),
              ),
            )
          ];
        },
        body: SingleChildScrollView(
          controller: kIsWeb
              ? null
              : Platform.isAndroid || Platform.isIOS
                  ? sc
                  : null,
          child: Column(
            children: screenWidth > 300
                ? [
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(restaurant.name,
                              style: Theme.of(context).textTheme.titleLarge),
                          Row(
                            children: [
                              const Icon(
                                Icons.location_on,
                                size: 16,
                              ),
                              const SizedBox(width: 5),
                              Text(restaurant.city,
                                  style: const TextStyle(fontSize: 16)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            restaurant.description,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "Menu:",
                            style: Theme.of(context).textTheme.headlineSmall,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "Makanan:",
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          ListView.builder(
                            controller: kIsWeb
                                ? null
                                : Platform.isAndroid || Platform.isIOS
                                    ? sc
                                    : null,
                            shrinkWrap: true,
                            itemCount: foods.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                tileColor:
                                    Theme.of(context).listTileTheme.tileColor,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16.0,
                                  vertical: 8.0,
                                ),
                                leading: Image.asset(
                                  'assets/pexels-ella-olsson-1640777.jpg',
                                  width: 100,
                                ),
                                title: Text(
                                  restaurant.menus['foods'][index]['name'],
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                              );
                            },
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "Minuman:",
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          ListView.builder(
                            controller: kIsWeb
                                ? null
                                : Platform.isAndroid || Platform.isIOS
                                    ? sc
                                    : null,
                            shrinkWrap: true,
                            itemCount: drinks.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                tileColor:
                                    Theme.of(context).listTileTheme.tileColor,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16.0,
                                  vertical: 8.0,
                                ),
                                leading: Image.asset(
                                  'assets/pexels-muhammad-fawdy-13573779.jpg',
                                  width: 100,
                                  fit: BoxFit.cover,
                                ),
                                title: Text(
                                  restaurant.menus['drinks'][index]['name'],
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ]
                : [],
          ),
        ),
      ),
    );
  }
}
